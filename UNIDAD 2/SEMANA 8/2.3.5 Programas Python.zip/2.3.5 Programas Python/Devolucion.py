#Devolución
user = input("ingrese  el usuario: ")
pwd  = input("Ingrese su password: ")

if user == "duoc" and pwd == "123duoc":
      valorDev = int(input("Bienvenido, Ingrese el valor a devolver: "))
      if valorDev > 100000:
        print("Se dará la máxima urgencia a su devolución de dinero")
      else:
        print("El caso ha quedado registrado, le informaremos lo antes posible")
else:
    print ("Error en contraseña")


