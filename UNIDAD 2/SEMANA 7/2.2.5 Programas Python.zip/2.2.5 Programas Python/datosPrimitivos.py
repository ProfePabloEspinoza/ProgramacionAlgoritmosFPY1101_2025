Edad = int(input("Ingrese su edad :"))
