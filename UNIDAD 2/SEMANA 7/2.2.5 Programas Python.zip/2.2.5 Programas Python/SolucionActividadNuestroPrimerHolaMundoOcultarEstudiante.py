#Para probar código eliminar triple comillas dobles.
#################################################### 
"""
#1A
print ("Bienvenido al mundo de la programación")
#1B
print ("Para comenzar, ingresa tu nombre :")
"""
####################################################
"""
#2 
nom = input ("Ingrese su nombre: ")
print (f"Bienvenido {nom}")
"""

####################################################
"""
#3
x = int(input("Ingrese el valor de X: "))
resultado = ((x**2)+3*x+1)/4
print (f"El resultado de la ecuación es: {resultado}")
"""
#####################################################
"""
#4
nom = input ("Ingrese nombre:   ")
rut = input ("Ingrese rut:      ")
correo = input ("Ingrese correo:   ")
telefono = int(input ("Ingrese telefono: "))

print (f"NOMBRE:\t\t{nom}")
print (f"RUT:\t\t{rut}")
print (f"CORREO:\t\t{correo}")
print (f"TELEFONO:\t{telefono}")
"""