# Tamaño del cuadrado
alto  = 10
ancho = 30
# Dibujo del cuadrado
for i in range(alto):
    for j in range(ancho):
        #Imprime un asterisco y coloca el * al lado de otro *
        print("*", end=" ")
    print()
