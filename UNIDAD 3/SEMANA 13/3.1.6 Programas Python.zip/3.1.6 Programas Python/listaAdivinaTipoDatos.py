#validaciónTipoDato
lista = ['Celular', 5000000, 'Computador', 4.3234,  '$"#$$#%/&']
try:
    print("Identificación del elemento ingresado")
    for l in lista:
        if(lista[0] == 'Celular'):
            print(f"El elemento {l}, que se encuentra en la posición {lista.index(l)} de la lista, Es número")
        elif(lista[1] == 5000000):
            print(f"El elemento {l}, que se encuentra en la posición {lista.index(l)} de la lista, Es un número")
        elif(lista[2] == 'Computador'):
            print(f"El elemento {l}, que se encuentra en la posición {lista.index(l)} de la lista, Es un texto")
        else:
            print(f"El elemento {l}, que se encuentra en la posición {lista.index(l)} de la lista, Es indeterminado")
except:
    print("Problemas al leer los datos")