matriz_sencilla = [
    [1, 2, 3],
    [4, 5, 6]
]
print("imprimir  matriz")
for elemento in matriz_sencilla:
    print(elemento)

print("imprimir un elemento por posición")
print(matriz_sencilla[1][0])

print("Imprimir todos los elementos de la matriz")
for fila in matriz_sencilla:
    for elemento in fila:
        print(elemento, end=' ')
    print() 