milista = [1,2,3,4,5]
milista.insert(3,"Juan")

for elemento in milista:
    print(elemento)